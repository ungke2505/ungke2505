import 'package:flutter/material.dart';

const fontSizeRegular = TextStyle(
  fontFamily: 'Ubuntu',
  fontWeight: FontWeight.w400,
);

const fontSizeMedium = TextStyle(
  fontFamily: 'Ubuntu',
  fontWeight: FontWeight.w500,
);

const fontSizeBold = TextStyle(
  fontFamily: 'Ubuntu',
  fontWeight: FontWeight.w600,
);

const fontSizeBlack = TextStyle(
  fontFamily: 'Ubuntu',
  fontWeight: FontWeight.w900,
);
const fontSizeLight = TextStyle(
  fontFamily: 'Ubuntu',
  fontWeight: FontWeight.w300,
);